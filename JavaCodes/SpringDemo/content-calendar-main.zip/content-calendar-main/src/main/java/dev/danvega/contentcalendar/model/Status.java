package dev.danvega.contentcalendar.model;

public enum Status {
    IDEA,
    IN_PROGRESS,
    COMPLETED,
    PUBLISHED,
}
