package dev.danvega.contentcalendar.model;

public enum Type {
    ARTICLE,
    VIDEO,
    COURSE,
    CONFERENCE_TALK
}
