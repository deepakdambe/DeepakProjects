package com.example.Employee_CURD_Demo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeCurdDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeCurdDemo1Application.class, args);
	}

}
