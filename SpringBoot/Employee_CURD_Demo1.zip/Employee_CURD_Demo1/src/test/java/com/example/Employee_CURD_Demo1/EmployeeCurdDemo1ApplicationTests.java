package com.example.Employee_CURD_Demo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeCurdDemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
